var express = require('express');
var app = express();

app.get('/', function(req,res){
    res.send('Hello World');
});

app.get('/aplicativo', function(req,res){
    res.send('Aplicativo Exemplo');
});

app.get('/html', function(req,res){
    res.send(' <!DOCTYPE html>   <head>        <meta charset="UTF-8">        <title>Mexa-se</title>   </head><body><h1>Lista 03 – Tecnologias Web</h1></body></html>'
        
        );
});

    app.post('/imagens', function(req,res){
        res.send('Imagem 1 – Imagem 2 – Imagem3')
    });


app.delete('/clientes/10', function(req,res){
    res.send('Cliente número 10 removido com sucesso');
});

app.listen(3000, function(){
    console.log('Exemplo app listenning on port 3000');
});
